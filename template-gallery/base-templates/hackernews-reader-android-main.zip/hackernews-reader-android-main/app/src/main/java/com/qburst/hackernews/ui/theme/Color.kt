package com.qburst.hackernews.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryOrange = Color(0xFFFF6600)
val PrimaryOrangeVariant = Color(0xFFC64F00)
val SecondaryOrange = Color(0xFFFF6600)
val PrimaryTextColor = Color(0xFF000000)